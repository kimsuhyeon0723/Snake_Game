#include "Monster.h"

int Monster::Act()
{
	srand(((unsigned int)time(NULL)));
	int act = rand() % 3 + 1;
	return act;
}

void Monster::ShowStat(int beginColumn)
{
	MapDraw::DrawMidText("=====" + m_strName + " <Lv." + to_string(m_iLv) + ">=====", WIDTH, beginColumn);
	MapDraw::TextDraw("���ݷ� : " + to_string(m_iAtk), SHOWSTATLEFT, beginColumn + 1);
	MapDraw::TextDraw("������ : " + to_string(m_iHP) + "/" + to_string(m_iHPMax), SHOWSTATRIGHT, beginColumn + 1);
	MapDraw::TextDraw("����ġ : " + to_string(m_iExp) + "/" + to_string(m_iExpMax), SHOWSTATLEFT, beginColumn + 2);
	MapDraw::TextDraw("����ð���ġ : " + to_string(m_iLootExp), SHOWSTATRIGHT, beginColumn + 2);
	MapDraw::TextDraw("Gold : " + to_string(m_iGold), SHOWSTATLEFT, beginColumn + 3);
}