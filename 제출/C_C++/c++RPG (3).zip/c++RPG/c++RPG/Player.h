#pragma once
#include "Mecro.h"
#include "Actor.h"
#include "MapDraw.h"
#include "Weapon.h"

class Player : public Actor
{
	int m_iWeaponNumber;
	Weapon* m_PlayerWeapon;
public:
	void MakeName();
	int Act();
	void ShowStat(int beginColumn);
	void Purchase(Weapon weapon, int cost);
	void SetWeaponNumber(int weaponNumber);
	int WeaponDamage();
	void SetWeapon(Weapon* weapon);
	int GetWeaponNumber();
	void WeaponStorage();
	Weapon* pGetWeaponStorage();
	Player();
	~Player();
};

