#include "Actor.h"

Actor::Actor()
{
	m_strName = "Name";
	m_iLv = 0;
	m_iAtk = 0;
	m_iHP = 0;
	m_iHPMax = 0;
	m_iExp = 0;
	m_iExpMax = 0;
	m_iLootExp = 0;
	m_iGold = 0;
}

Actor::~Actor()
{

}


void Actor::SetStat(string strName, int iLv, int iAtk, int iHP, int iHPMax, int iExp, int iExpMax, int iLootExp, int iGold)
{
	m_strName = strName;
	m_iLv = iLv;
	m_iAtk = iAtk;
	m_iHP = iHP;
	m_iHPMax = iHPMax;
	m_iExp = iExp;
	m_iExpMax = iExpMax;
	m_iLootExp = iLootExp;
	m_iGold = iGold;
}

void Actor::RenewalStatManage(string& strName, int& iLv, int& iAtk, int& iHP, int& iHPMax, int& iExp, int& iExpMax, int& iLootExp, int& iGold)
{
	strName = m_strName;
	iLv = m_iLv;
	iAtk = m_iAtk;
	iHP = m_iHP;
	iHPMax = m_iHPMax;
	iExp = m_iExp;
	iExpMax = m_iExpMax;
	iLootExp = m_iLootExp;
	iGold = m_iGold;
}

string Actor::GetName()
{
	return m_strName;
}

void Actor::Damage(int damage)
{
	m_iHP = m_iHP - damage;
}

int Actor::GetAtk()
{
	return m_iAtk;
}

int Actor::GetHP()
{
	return m_iHP;
}

void Actor::resetHp()
{
	m_iHP = m_iHPMax;
}

void Actor::resetExp()
{
	m_iExp = m_iExpMax;
}

void Actor::LevelUp()
{
	m_iLv++;
	m_iExp = 0;
	m_iExpMax += 3;
	m_iHPMax += 8;
	m_iAtk += 4;
	resetHp();
}

int Actor::GetGold()
{
	return m_iGold;
}

int Actor::GetLootExp()
{
	return m_iLootExp;
}

void Actor::ResultGold(int addGold)
{
	m_iGold += addGold;
}

void Actor::ResultExp(int addExp)
{
	m_iExp += addExp;
}

bool Actor::ExpOverCheck()
{
	if (m_iExp >= m_iExpMax)
	{
		return true;
	}
	else
	{
		return false;
	}
}





