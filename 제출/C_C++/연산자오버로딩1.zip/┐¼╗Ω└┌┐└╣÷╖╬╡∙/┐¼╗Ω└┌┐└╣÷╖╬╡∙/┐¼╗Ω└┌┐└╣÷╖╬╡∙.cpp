﻿#include <iostream>
using namespace std;

class Number
{
	int num;
public:
	friend Number operator / (Number tmp1, Number tmp2);
	void Print() { cout << num; }
	Number(int n) { num = n; }
	Number() : num(0){}
};

Number operator / (Number tmp1, Number tmp2) //int 로도 가능했음
{

	if (tmp2.num == 0)
	{
		cout << "0으로 나눌수 없음\n";
		return 0;
	}
	else
	{
		Number tmp;
		tmp = tmp1.num / tmp2.num;
		return tmp;
	}
}

void main()
{
	Number n1(6), n2(3), n3;
	n3 = n1 / n2;
	n3.Print();
}
