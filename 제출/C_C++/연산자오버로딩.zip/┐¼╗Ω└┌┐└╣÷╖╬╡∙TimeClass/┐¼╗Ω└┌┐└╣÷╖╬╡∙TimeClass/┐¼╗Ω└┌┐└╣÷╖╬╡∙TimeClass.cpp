﻿#include <iostream>
using namespace std;

class Time
{
	int m_iHour;
	int m_iMin;
public:
	void ShowTime() { cout << m_iHour << "시간, " << m_iMin << "분"; }
	Time operator + (Time time);
	Time() { m_iHour = 0; m_iMin = 0;}
	Time(int Hour, int Min);
	~Time() {};
};

Time::Time(int Hour, int Min)
{
	if (Min >= 60)
	{
		Min -= 60;
		m_iMin = Min;
		m_iHour = ++Hour;
	}
	else
	{
		m_iMin = Min;
		m_iHour = Hour;
	}
}

Time Time::operator+(Time time)
{
	Time tmpTime;
	tmpTime.m_iHour = this->m_iHour + time.m_iHour;
	tmpTime.m_iMin = this->m_iMin + time.m_iMin;
	if (tmpTime.m_iMin >= 60)
	{
		m_iMin -= 60;
		m_iHour++;
	}
	return tmpTime;
}

int main()
{
	Time t1(1, 63), t2(1, 4), t3;
	t3 = t1 + t2;
	t3.ShowTime();
}

