#pragma once
#include "Mecro.h"
#include "MapDraw.h"

class Weapon
{
protected:
	string m_strWeaponType;
	string m_strWeaponName;
	int m_iDamage;
	int m_iCost;
public:
	void ShowInformation(int x, int y);
	void ShowCost(int x, int y);
	int GetDamage();
	int GetCost();
	void SetData(string strWeaponType, string strWeaponName, int iDamage, int iCost);
	string GetWeaponType();
};

