#pragma once
#include<iostream>
#include<Windows.h>
#include<conio.h>
#include<string>
#include<fstream>
#include<time.h>
#include<vector>
using namespace std;

//////////////////////////////////////////////////////
#define col GetStdHandle(STD_OUTPUT_HANDLE) 
#define BLACK SetConsoleTextAttribute( col,0x0000 );
#define DARK_BLUE SetConsoleTextAttribute( col,0x0001 );
#define GREEN SetConsoleTextAttribute( col,0x0002 );
#define BLUE_GREEN SetConsoleTextAttribute( col,0x0003 );
#define BLOOD SetConsoleTextAttribute( col,0x0004 );
#define PUPPLE SetConsoleTextAttribute( col,0x0005 );
#define GOLD SetConsoleTextAttribute( col,0x0006 );			//���� ����
#define ORIGINAL SetConsoleTextAttribute( col,0x0007 );
#define GRAY SetConsoleTextAttribute( col,0x0008 );
#define BLUE SetConsoleTextAttribute( col,0x0009 );
#define HIGH_GREEN SetConsoleTextAttribute( col,0x000a );
#define SKY_BLUE SetConsoleTextAttribute( col,0x000b );
#define RED SetConsoleTextAttribute( col,0x000c );
#define PLUM SetConsoleTextAttribute( col,0x000d );
#define YELLOW SetConsoleTextAttribute( col,0x000e );
//////////////////////////////////////////////////////
#define WIDTH 30
#define HEIGHT 30
#define SHOWSTATLEFT 15
#define SHOWSTATRIGHT 33
#define DEFAULT 0
#define SELECTED 1
#define SCISSORS 1
#define ROCK 2
#define PAPER 3
#define BOW weaponBeginIdxSum[0]
#define DAGGER weaponBeginIdxSum[1]
#define GUN weaponBeginIdxSum[2]
#define SWORD weaponBeginIdxSum[3]
#define WAND weaponBeginIdxSum[4]
#define HAMMER weaponBeginIdxSum[5]
#define PLAYER m_iMonsterNumber + 1
#define ACTOR m_iMonsterNumber + 2

enum MAINMENU
{
	MAINMENU_NEWSTART = 1,
	MAINMENU_LOADSTART,
	MAINMENU_GAMEEND
};

enum GAMEMENU
{
	GAMEMENU_DUNGEON =1,
	GAMEMENU_PLAYERINFO,
	GAMEMENU_MONSTERINFO,
	GAMEMENU_WEAPONSHOP,
	GAMEMENU_SAVE,
	GAMEMENU_EXIT
};

enum SLOT
{
	SLOT_1 = 1,
	SLOT_2,
	SLOT_3,
	SLOT_4,
	SLOT_5,
	SLOT_6,
	SLOT_7,
	SLOT_8,
	SLOT_9,
	SLOT_10,
	SLOT_BACK
};

enum DUNGEON
{
	DUNGEON_1 = 1,
	DUNGEON_2,
	DUNGEON_3,
	DUNGEON_4,
	DUNGEON_5,
	DUNGEON_6,
	DUNGEON_BACK
};

enum WEAPONTYPE
{
	WEAPONTYPE_BOW,
	WEAPONTYPE_DAGGER,
	WEAPONTYPE_GUN,
	WEAPONTYPE_SWORD,
	WEAPONTYPE_WAND,
	WEAPONTYPE_HAMMER,
	WEAPONTYPE_NUMBER
};

enum SHOP
{
	SHOP_BOW = 1,
	SHOP_DAGGER,
	SHOP_GUN,
	SHOP_SWORD,
	SHOP_WAND,
	SHOP_HAMMER,
	SHOP_NUMBER
};