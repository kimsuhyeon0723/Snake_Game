#include "Player.h"
Player::Player()
{
	m_strName = "Name";
	m_iLv = 0;
	m_iAtk = 0;
	m_iHP = 0;
	m_iHPMax = 0;
	m_iExp = 0;
	m_iExpMax = 0;
	m_iLootExp = 0;
	m_iGold = 0;	
	m_PlayerWeapon = nullptr;
}

void Player::MakeName()
{
	system("cls");
	MapDraw::BoxDraw(0, 0, WIDTH, HEIGHT);
	MapDraw::DrawMidText("Player �̸� : ", WIDTH, HEIGHT / 2);
	cin >> m_strName;
}

int Player::Act()
{
	char ch;
	ch = getch();
	int act = 0;
	while (1)
	{
		if (ch == '1')
		{
			act = SCISSORS;
			break;
		}
		else if (ch == '2')
		{
			act = ROCK;
			break;
		}
		else if (ch == '3')
		{
			act = PAPER;
			break;
		}
		else
		{
			srand(((unsigned int)time(NULL)));
			act = rand() % 3 + 1;
			break;
		}
	}	
	return act;
}

void Player::ShowStat(int beginColumn)
{
	MapDraw::DrawMidText("=====" + m_strName + " <Lv." + to_string(m_iLv) + ">=====", WIDTH, beginColumn);
	MapDraw::TextDraw("���ݷ� : " + to_string(m_iAtk), SHOWSTATLEFT, beginColumn + 1);
	MapDraw::TextDraw("������ : " + to_string(m_iHP) + "/" + to_string(m_iHPMax), SHOWSTATRIGHT, beginColumn + 1);
	MapDraw::TextDraw("����ġ : " + to_string(m_iExp) + "/" + to_string(m_iExpMax), SHOWSTATLEFT, beginColumn + 2);
	MapDraw::TextDraw("����ð���ġ : " + to_string(m_iLootExp), SHOWSTATRIGHT, beginColumn + 2);
	MapDraw::TextDraw("Gold : " + to_string(m_iGold), SHOWSTATLEFT, beginColumn + 3);

	if (m_PlayerWeapon != nullptr)
	{
		m_PlayerWeapon->ShowInformation(4, beginColumn + 4);
	}
}

void Player::Purchase(Weapon weapon, int cost)
{
	if (m_PlayerWeapon != nullptr)
	{
		*m_PlayerWeapon = weapon;
		m_iGold -= cost;
	}	
}

void Player::SetWeaponNumber(int weaponNumber)
{
	m_iWeaponNumber = weaponNumber;
}

int Player::WeaponDamage()
{
	if (m_PlayerWeapon != nullptr && m_iWeaponNumber > 0)
		return m_PlayerWeapon->GetDamage();
	else
		return 0;
}

void Player::SetWeapon(Weapon* weapon)
{
	if (m_iWeaponNumber > 0)
	{
		*m_PlayerWeapon = weapon[m_iWeaponNumber];
	}
		
}

int Player::GetWeaponNumber()
{
	return m_iWeaponNumber;
}

void Player::WeaponStorage()
{
	m_PlayerWeapon = new Weapon;
}

Player::~Player()
{
	delete m_PlayerWeapon;
}

