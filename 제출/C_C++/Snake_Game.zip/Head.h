#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include <conio.h>
#include <time.h>
#include <list>
using namespace std;

enum MAPSIZE
{
	MAPSIZE_HEIGHT = 30,
	MAPSIZE_WIDTH = 50
};


