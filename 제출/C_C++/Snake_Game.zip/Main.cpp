﻿#include "Manager.h"

void main()
{
	Manager m;
	m.Init();    
}
