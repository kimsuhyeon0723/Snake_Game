#pragma once
#include "Head.h"
#include "Draw.h"

enum DIRECTION
{
	DIRECTION_N = 0,
	DIRECTION_UP,
	DIRECTION_DOWN,
	DIRECTION_LEFT,
	DIRECTION_RIGHT = 4	
};

struct SnakeBody
{
	int x = 0;
	int y = 0;
	DIRECTION direction = DIRECTION_N;
	string image = "��";
};

class Snake
{
	int m_iMovableWidth;
	int m_iMovableHeight;
	int m_iSnakeClock;
	bool m_bCollision;
	list<SnakeBody> m_SnakeBody;
	Draw m_Draw;
public:
	Snake();
	void MakeSnakeBody();
	void Move();
	void Input();
	void DrawSnake();
	void EraseSnake();
	inline int GetHeadx() { return m_SnakeBody.begin()->x; }
	inline int GetHeady() { return m_SnakeBody.begin()->y; }
	inline int GetDirection() { return m_SnakeBody.begin()->direction; }
	inline int GetSnakeClock() { return m_iSnakeClock; }
	inline void SetSnakeClock(int clock) { m_iSnakeClock = clock; }
	void SnakeCollision();
	bool CheckCollision();
	void ClearSnake();
	void CollisionReset();
	void MakingConditions(SnakeBody& tail, SnakeBody body);
};
