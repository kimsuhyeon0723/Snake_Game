#include "Snake.h"

Snake::Snake()
{
	m_iMovableWidth = MAPSIZE_WIDTH;
	m_iMovableHeight = MAPSIZE_HEIGHT;
	m_iSnakeClock = clock();
	m_bCollision = false;
}

void Snake::MakeSnakeBody()
{
	SnakeBody b;
	if (m_SnakeBody.empty())
	{
		b.direction = DIRECTION_N;
		b.image = "��";
		b.x = m_iMovableWidth / 2;
		b.y = m_iMovableHeight / 2;
	}
	else
	{
		MakingConditions(b, m_SnakeBody.back());
	}	
	m_SnakeBody.push_back(b);
}

void Snake::Move()
{

	for (auto iter = m_SnakeBody.begin(); iter != m_SnakeBody.end(); iter++) //�����Ȳ��� ���� ��� ������
	{
		if (iter->direction == DIRECTION_LEFT)
			iter->x--;
		else if (iter->direction == DIRECTION_RIGHT)
			iter->x++;
		else if (iter->direction == DIRECTION_UP)
			iter->y--;
		else if (iter->direction == DIRECTION_DOWN)
			iter->y++;
	}

	DIRECTION saveDirection = DIRECTION_N;
	DIRECTION tmpDireciton = DIRECTION_N;

	for (auto iter = m_SnakeBody.begin(); iter != m_SnakeBody.end(); iter++)
	{
		//save�� ���� �ε����� �޾ƾ��Ұ��� ���� ����
		//tmp�� �ޱ����� �Ű� ����
		if (iter != m_SnakeBody.begin())//2��° ���� �Ѱ��ִ� ����
		{
			tmpDireciton = iter->direction;
			iter->direction = saveDirection;
			saveDirection = tmpDireciton;
		}
		else
		{
			saveDirection = iter->direction;
		}

	}

	m_iSnakeClock = clock();
}

void Snake::Input()
{
	char ch = getch();
	switch (ch)
	{
	case 'a':
	case 'A':
		if (m_SnakeBody.begin()->direction != DIRECTION_RIGHT)
			m_SnakeBody.begin()->direction = DIRECTION_LEFT;
		break;
	case 'd':
	case 'D':
		if (m_SnakeBody.begin()->direction != DIRECTION_LEFT)
			m_SnakeBody.begin()->direction = DIRECTION_RIGHT;
		break;
	case 'w':
	case 'W':
		if (m_SnakeBody.begin()->direction != DIRECTION_DOWN)
			m_SnakeBody.begin()->direction = DIRECTION_UP;
		break;
	case 's':
	case 'S':
		if (m_SnakeBody.begin()->direction != DIRECTION_UP)
			m_SnakeBody.begin()->direction = DIRECTION_DOWN;
		break;
	default:
		break;
	}
}

void Snake::DrawSnake()
{	
	if (!m_SnakeBody.empty())
	{
		for (auto iter = m_SnakeBody.begin(); iter != m_SnakeBody.end(); iter++)
		{
			m_Draw.DrawPoint(iter->x, iter->y, iter->image);
		}
	}
}
	
void Snake::EraseSnake()
{
	if (!m_SnakeBody.empty())
	{
		for (auto iter = m_SnakeBody.begin(); iter != m_SnakeBody.end(); iter++)
		{
			m_Draw.DrawPoint(m_SnakeBody.back().x, m_SnakeBody.back().y, "  ");
		}
		
	}	
}

void Snake::SnakeCollision()//�� ���, �ڽ� �浹
{
	if (m_SnakeBody.begin()->x == 0 || m_SnakeBody.begin()->y == 0 ||
		m_SnakeBody.begin()->x == m_iMovableWidth - 1 || m_SnakeBody.begin()->y == m_iMovableHeight - 1)
	{
		m_bCollision = true;
	}

	if (m_SnakeBody.size() > 1)
	{
		for (auto iter = m_SnakeBody.begin(); iter != m_SnakeBody.end(); iter++)
		{
			if (iter == m_SnakeBody.begin())
				iter++;

			if (m_SnakeBody.begin()->x == iter->x && m_SnakeBody.begin()->y == iter->y)
			{
				m_bCollision = true;
			}
		}
	}	
}

bool Snake::CheckCollision()
{
	return m_bCollision;
}

void Snake::ClearSnake()
{
	m_SnakeBody.clear();
}


void Snake::CollisionReset()
{
	m_bCollision = false;
}

void Snake::MakingConditions(SnakeBody& tail, SnakeBody back)//t�� �����, h�� t�� ���� ��������
{
	if (back.direction == DIRECTION_LEFT)
	{
		tail.x = ++back.x;
		tail.y = back.y;
	}
	else if (back.direction == DIRECTION_RIGHT)
	{
		tail.x = --back.x;
		tail.y = back.y;
	}
	else if (back.direction == DIRECTION_UP)
	{
		tail.x = back.x;
		tail.y = ++back.y;
	}
	else if (back.direction == DIRECTION_DOWN)
	{
		tail.x = back.x;
		tail.y = --back.y;
	}
	tail.image = "��";
	tail.direction = back.direction;
}
