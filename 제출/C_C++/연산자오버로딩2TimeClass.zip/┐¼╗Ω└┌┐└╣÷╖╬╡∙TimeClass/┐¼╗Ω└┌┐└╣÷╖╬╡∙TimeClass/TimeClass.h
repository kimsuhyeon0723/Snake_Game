#pragma once
#include "head.h"

class Time
{
		int m_iHour;
		int m_iMin;
	public:
		void ShowTime() { cout << m_iHour << "�ð�, " << m_iMin << "��"; }
		Time operator + (Time time);
		Time() { m_iHour = 0; m_iMin = 0; }
		Time(int Hour, int Min);
		~Time() {};
};

