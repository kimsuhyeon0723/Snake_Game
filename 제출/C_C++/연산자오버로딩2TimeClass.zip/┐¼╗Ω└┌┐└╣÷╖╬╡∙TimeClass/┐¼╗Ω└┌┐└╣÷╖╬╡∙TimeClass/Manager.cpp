#include "Manager.h"

void Manager::ShowTotalTime()
{
	cout << "\t�� ���� �ð� - "; m_Total.ShowTime();
	cout << endl;
}

Time Manager::MakeTime(int hour, int min)
{
	return Time(hour, min);
}

void Manager::SumTime(int hour, int min)
{
	m_Total = m_Total + MakeTime(hour, min);
	m_iDayCount++;
}

void Manager::Menu()
{
	int hour = 0, min = 0;
	cout << "====���� �ð� ���� ���α׷�<" << m_iDayCount << " Day>====" << endl;
	cout << "\t1.�ð� ���\n\t2.����\n\t�Է� : ";
	cin >> m_iInput;
	if (m_iInput == 1)
	{
		cout << "�ð� : ";
		cin >> hour;
		cout << "�� : ";
		cin >> min;
		SumTime(hour, min);
	}
	else if (m_iInput == 2)
		return;
}

void Manager::Manage()
{
	while (m_iInput != 2)
	{
		system("cls");
		ShowTotalTime();
		Menu();
	}
}