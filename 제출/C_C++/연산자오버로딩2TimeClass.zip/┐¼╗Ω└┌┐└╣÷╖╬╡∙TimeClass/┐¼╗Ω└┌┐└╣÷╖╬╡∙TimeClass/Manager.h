#pragma once
#include "head.h"
#include "TimeClass.h"

class Manager
{
	Time m_Total;
	int m_iDayCount;
	int m_iInput;
public:
	void ShowTotalTime();
	Time MakeTime(int hour, int min);
	void SumTime(int hour, int min);
	void Menu();
	void Manage();
	Manager(): m_iDayCount(0), m_iInput(0) {}
};

