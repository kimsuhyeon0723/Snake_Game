﻿#include "head.h"
#include "Manager.h"
#include "TimeClass.h"

int main()
{
	Manager TimeManager;
	TimeManager.Manage();
}

