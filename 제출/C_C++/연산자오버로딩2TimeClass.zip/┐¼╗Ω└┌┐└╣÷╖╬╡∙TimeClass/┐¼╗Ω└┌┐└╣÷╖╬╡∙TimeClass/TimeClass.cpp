#include "TimeClass.h"

Time::Time(int Hour, int Min)
{
	if (Min >= 60)
	{
		Min -= 60;
		m_iMin = Min;
		m_iHour = ++Hour;
	}
	else
	{
		m_iMin = Min;
		m_iHour = Hour;
	}
}

Time Time::operator+(Time time)
{
	Time tmpTime;
	tmpTime.m_iHour = this->m_iHour + time.m_iHour;
	tmpTime.m_iMin = this->m_iMin + time.m_iMin;
	if (tmpTime.m_iMin >= 60)
	{
		tmpTime.m_iMin -= 60;
		tmpTime.m_iHour++;
	}
	return tmpTime;
}