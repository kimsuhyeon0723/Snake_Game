#pragma once
#include "Mecro.h"
#include "MapDraw.h"
#include "Player.h"
#include "Monster.h"
#include "Weapon.h"

struct ActorData
{
	string strName = "Name";
	int iLv = 0;
	int iAtk = 0;
	int iHP = 0;
	int iHPMax = 0;
	int iExp = 0;
	int iExpMax = 0;
	int iLootExp = 0;
	int iGold = 0;
};

class GameManager //�ؾ��Ұ� ���������� ����������, �ҷ�����, �����޴� �����, �÷��̾� �������� ǥ���ϱ� 
{
	int m_iGameWidth;
	int m_iGameHeight;
	int m_iMonsterNumber;
	int m_iWeaponNumber;
	int m_iWeaponCount[WEAPONTYPE_NUMBER];//�� Ÿ�Ժ� ����
	bool m_bGameOver;
	Player m_Player;
	Monster* m_Monster;
	MapDraw m_MapDraw;
	ofstream m_Save;
	ifstream m_Load;
	ActorData* m_ActorData;
	Weapon* m_Weapon;
public:
	GameManager();
	~GameManager();
	void Init();
	void StartMenu();
	void GameMenu();
	void ScreenSizeControl(int Width, int Height);
	void Ingame();
	void SaveSlot();
	int LoadSlot();
	void Save();
	void Save(int slot);
	void Load();
	bool Load(int slot);
	void RenewalActorData();
	void BattleScene(int select);
	void Battle(int select);
	void SelectDungeon();
	void BattleResult(int select);
	void LevelUpCheck(int select);
	void WeaponList();
	void WeaponSetting();
	void WeaponShopMenu();
	void WeaponPurchaseMenu(int select);
	void WeaponTypeShopText(int select);
	void WeaponPurchaseSelect(int select, string weaponType);
};

