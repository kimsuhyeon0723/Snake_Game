#include "GameManager.h"

GameManager::GameManager()
{
	m_iGameWidth = WIDTH;
	m_iGameHeight = HEIGHT;
	m_iMonsterNumber = 0;
	m_ActorData = NULL;
	m_Monster = NULL;
	m_iWeaponNumber = 0;
	m_bGameOver = false;
}

GameManager::~GameManager()
{

}

void GameManager::Init()
{
	int select = 0;
	ScreenSizeControl(m_iGameHeight, m_iGameWidth);
	while (select != 3)
	{
		m_bGameOver = false;
		system("cls");
		MapDraw::BoxDraw(0,0,m_iGameWidth, m_iGameHeight);
		StartMenu();
		select = MapDraw::MenuSelectCursor(3, 2, m_iGameWidth/2 -6, m_iGameHeight/3 + 2);
		switch (select)
		{
		case 1://������			
			Save();//�÷��̾�� ���� ������ �ؽ�Ʈ�� �����Ѵ�.
			Load();//�÷��̾�� ���� ������ ����ü�� �����Ѵ�. actordata�����Ҵ� ���Ϳ� �÷��̾���� ����
			WeaponList();//����� ���� �ؽ�Ʈ�� ����
			WeaponSetting(); //���������� ��ü�鿡�� ����
			m_Monster = new Monster[m_iMonsterNumber]; //���� ����ŭ �����Ҵ�				
			m_Player.SetStat(m_ActorData[PLAYER].strName, m_ActorData[PLAYER].iLv, m_ActorData[PLAYER].iAtk, m_ActorData[PLAYER].iHP, m_ActorData[PLAYER].iHPMax, m_ActorData[PLAYER].iExp, m_ActorData[PLAYER].iExpMax, m_ActorData[PLAYER].iLootExp, m_ActorData[PLAYER].iGold);
			m_Player.MakeName(); //�÷��̾� ��ü�� ���� �Ѱ��ְ� �̸� ���ϴ� �Լ�
			for (int i = 0; i < m_iMonsterNumber; i++)//���� ��ü�� ���� �����ϱ�
			{
				m_Monster[i].SetStat(m_ActorData[i].strName, m_ActorData[i].iLv, m_ActorData[i].iAtk, m_ActorData[i].iHP, m_ActorData[i].iHPMax, m_ActorData[i].iExp, m_ActorData[i].iExpMax, m_ActorData[i].iLootExp, m_ActorData[i].iGold);
			}
			
			Ingame();
			delete[] m_Monster;
			delete[] m_ActorData;
			delete[] m_Weapon;
			break;
		case 2://�ε� 
			system("cls");
			MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
			WeaponSetting();
			select = LoadSlot();
			if (select != SLOT_BACK && Load(select) != false)
			{				
				m_Player.SetStat(m_ActorData[PLAYER].strName, m_ActorData[PLAYER].iLv, m_ActorData[PLAYER].iAtk, m_ActorData[PLAYER].iHP, m_ActorData[PLAYER].iHPMax, m_ActorData[PLAYER].iExp, m_ActorData[PLAYER].iExpMax, m_ActorData[PLAYER].iLootExp, m_ActorData[PLAYER].iGold);
				
				m_Monster = new Monster[m_iMonsterNumber];
				for (int i = 0; i < m_iMonsterNumber; i++)
				{
					m_Monster[i].SetStat(m_ActorData[i].strName, m_ActorData[i].iLv, m_ActorData[i].iAtk, m_ActorData[i].iHP, m_ActorData[i].iHPMax, m_ActorData[i].iExp, m_ActorData[i].iExpMax, m_ActorData[i].iLootExp, m_ActorData[i].iGold);
				}
				
				system("cls");
				MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
				Ingame();
				delete[] m_Monster;
				delete[] m_ActorData;
				delete[] m_Weapon;
			}			
			break;
		case 3://����	
			return;
		default:
			break;
		}
	}
}

void GameManager::StartMenu()
{
	MapDraw::DrawMidText("�ڡ� DungeonRPG �ڡ�", m_iGameWidth, m_iGameHeight / 3);
	MapDraw::DrawMidText("New Game", m_iGameWidth, m_iGameHeight / 3 + 2);
	MapDraw::DrawMidText("Load Game", m_iGameWidth, m_iGameHeight / 3 + 4);
	MapDraw::DrawMidText("Game Exit", m_iGameWidth, m_iGameHeight / 3 + 6);
}

void GameManager::GameMenu()
{
	YELLOW
	MapDraw::DrawMidText("�ڡ� Menu �ڡ�", m_iGameWidth, m_iGameHeight / 3);
	MapDraw::DrawMidText("Dungeon", m_iGameWidth, m_iGameHeight / 3 + 2);
	MapDraw::DrawMidText("Player Info", m_iGameWidth, m_iGameHeight / 3 + 4);
	MapDraw::DrawMidText("Monster Info", m_iGameWidth, m_iGameHeight / 3 + 6);
	MapDraw::DrawMidText("Weapon Shop", m_iGameWidth, m_iGameHeight / 3 + 8);
	MapDraw::DrawMidText("Save", m_iGameWidth, m_iGameHeight / 3 + 10);
	MapDraw::DrawMidText("Exit", m_iGameWidth, m_iGameHeight / 3 + 12);
	ORIGINAL
}

void GameManager::ScreenSizeControl(int Width, int Height)
{
	char buf[256];
	sprintf(buf, "mode con: lines=%d cols=%d", Height + 1, Width * 2 + 1);
	system(buf);
}

void GameManager::Ingame()
{
	int select = 1;
	while (select != GAMEMENU_EXIT && m_bGameOver == false)
	{
		system("cls");
		MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
		GameMenu();
		select = MapDraw::MenuSelectCursor(6, 2, m_iGameWidth / 2 - 6, m_iGameHeight / 3 + 2);//6��
		switch ((GAMEMENU)select)
		{
		case GAMEMENU_DUNGEON:
			system("cls");
			MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
			SelectDungeon();
			break;
		case GAMEMENU_PLAYERINFO:
			system("cls");
			MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
			m_Player.ShowStat(m_iGameHeight / 2);
			cout << endl;
			getch();
			break;
		case GAMEMENU_MONSTERINFO:
			system("cls");
			MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
			for (int i = 0; i < m_iMonsterNumber; i++)
			{
				m_Monster[i].ShowStat(2 + 4 * i);
			}
			getch();
			break;
		case GAMEMENU_WEAPONSHOP:
			system("cls");
			WeaponShopMenu(); 
			break;
		case GAMEMENU_SAVE:
			system("cls");			
			MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
			RenewalActorData();//�����Ұ� ����
			SaveSlot();
			break;
		case GAMEMENU_EXIT:
			break;
		default:
			break;
		}
	}
}

void GameManager::SaveSlot()//���� ���� Ȯ��
{
	int slotMenu = 11;
	int select = 1;
	while (select != SLOT_BACK)
	{
		system("cls");
		MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);

		for (int i = 1; i < slotMenu; i++)
		{
			MapDraw::DrawMidText(to_string(i) + "�� ���� : ���� ", m_iGameWidth, i * 2 + 1);
			m_Load.open("SavePlayer" + to_string(i) + ".txt");
			if (m_Load.good())
				cout << "O";
			else
				cout << "X";
			m_Load.close();
		}
		MapDraw::DrawMidText("�ڷ� ����  ", m_iGameWidth, slotMenu * 2 + 1);
		select = MapDraw::MenuSelectCursor(slotMenu, 2, m_iGameWidth / 2 - 6, 3);
		if (select >= SLOT_1 && select <= SLOT_10)
		{
			Save(select);
		}
		else if (select == SLOT_BACK)
			return;
		else
			continue;
		
	}
	
}


int GameManager::LoadSlot()//���������� ���°��ε�, �ڷΰ��� �Ҷ� �����Ұ�
{	
	int slotMenu = 11;
	int select = 1;
	for (int i = 1; i < slotMenu; i++)
	{
		MapDraw::DrawMidText(to_string(i) + "�� ���� : ", m_iGameWidth, i * 2 + 1);
		m_Load.open("SavePlayer" + to_string(i) + ".txt");
		if (m_Load.good())
			cout << "O";
		else
			cout << "X";
		m_Load.close();
	}
	MapDraw::DrawMidText("�ڷ� ����  ", m_iGameWidth, slotMenu * 2 + 1);
	select = MapDraw::MenuSelectCursor(slotMenu, 2, m_iGameWidth / 2 - 6, 3);
	return select;
}

void GameManager::Save()//�̸�, ����, ���ݷ�, ����ü��, �ִ�ü��, ��������ġ, �ִ����ġ, ����� ����ġ, ����� ���
{
	m_Save.open("DefaultPlayer.txt");
	if (m_Save.is_open())
	{
		m_Save << "Name" << " " << 1 << " " << 5
			<< " " << 50 << " " << 50 << " " << 0
			<< " " << 10 << " " << 0 << " " << 0 << endl;
		m_Save << -1;
	}
	m_Save.close();

	m_Save.open("DefaultMonsters.txt");
	if (m_Save.is_open())
	{
		m_Save << 6 << endl
			<< "������" << " " << 1 << " " << 3 << " " << 20 << " " << 20 << " " << 0 << " " << 5 << " " << 5 << " " << 5 << endl
			<< "��ũ" << " " << 1 << " " << 20 << " " << 100 << " " << 100 << " " << 0 << " " << 20 << " " << 50 << " " << 10 << endl
			<< "�����ΰ�" << " " << 1 << " " << 50 << " " << 250 << " " << 250 << " " << 0 << " " << 50 << " " << 250 << " " << 20 << endl
			<< "�����" << " " << 1 << " " << 120 << " " << 500 << " " << 500 << " " << 0 << " " << 500 << " " << 700 << " " << 40 << endl
			<< "���̷���" << " " << 1 << " " << 200 << " " << 800 << " " << 800 << " " << 0 << " " << 200 << " " << 1500 << " " << 80 << endl
			<< "��ġ" << " " << 1 << " " << 300 << " " << 3000 << " " << 3000 << " " << 0 << " " << 300 << " " << 3000 << " " << 160;
	}
	m_Save.close();
}

void GameManager::Save(int select)
{
	m_Save.open("SavePlayer" + to_string(select) + ".txt");
	if (m_Save.is_open())
	{
		m_Save << m_ActorData[PLAYER].strName << " " << m_ActorData[PLAYER].iLv << " " << m_ActorData[PLAYER].iAtk
			<< " " << m_ActorData[PLAYER].iHP << " " << m_ActorData[PLAYER].iHPMax << " " << m_ActorData[PLAYER].iExp
			<< " " << m_ActorData[PLAYER].iExpMax << " " << m_ActorData[PLAYER].iLootExp << " " << m_ActorData[PLAYER].iGold << endl;
		m_Save << m_Player.GetWeaponNumber();
	}
	m_Save.close();

	m_Save.open("SaveMonsters" + to_string(select) + ".txt");
	if (m_Save.is_open())
	{
		m_Save << m_iMonsterNumber << endl;
		for (int i = 0; i < m_iMonsterNumber; i++)
		{			
			m_Save << m_ActorData[i].strName << " " << m_ActorData[i].iLv << " " << m_ActorData[i].iAtk
				<< " " << m_ActorData[i].iHP << " " << m_ActorData[i].iHPMax << " " << m_ActorData[i].iExp
				<< " " << m_ActorData[i].iExpMax << " " << m_ActorData[i].iLootExp << " " << m_ActorData[i].iGold << endl;
		}
	}
	m_Save.close();
}

void GameManager::Load()
{		
	m_Load.open("DefaultMonsters.txt");
	m_Load >> m_iMonsterNumber;	
	m_ActorData = new ActorData[ACTOR];
	for (int i = 0; i < m_iMonsterNumber; i++)
	{
		m_Load >> m_ActorData[i].strName >> m_ActorData[i].iLv >> m_ActorData[i].iAtk
			>> m_ActorData[i].iHP >> m_ActorData[i].iHPMax >> m_ActorData[i].iExp
			>> m_ActorData[i].iExpMax >> m_ActorData[i].iLootExp >> m_ActorData[i].iGold;
	}
	m_Load.close();	

	m_Load.open("DefaultPlayer.txt");
	m_Load >> m_ActorData[PLAYER].strName >> m_ActorData[PLAYER].iLv >> m_ActorData[PLAYER].iAtk >> m_ActorData[PLAYER].iHP >> m_ActorData[PLAYER].iHPMax
		>> m_ActorData[PLAYER].iExp >> m_ActorData[PLAYER].iExpMax >> m_ActorData[PLAYER].iLootExp >> m_ActorData[PLAYER].iGold;

	int tmpWeaponNumber = -1;
	m_Load >> tmpWeaponNumber;
	m_Player.SetWeaponNumber(tmpWeaponNumber);
	m_Load.close();
}

bool GameManager::Load(int select)
{
	m_Load.open("SaveMonsters" + to_string(select) + ".txt");

	if (m_Load.good())
	{
		while (!m_Load.eof())
		{
			m_Load >> m_iMonsterNumber;
			m_ActorData = new ActorData[ACTOR];
			for (int i = 0; i < m_iMonsterNumber; i++)
			{
				m_Load >> m_ActorData[i].strName >> m_ActorData[i].iLv >> m_ActorData[i].iAtk
					>> m_ActorData[i].iHP >> m_ActorData[i].iHPMax >> m_ActorData[i].iExp
					>> m_ActorData[i].iExpMax >> m_ActorData[i].iLootExp >> m_ActorData[i].iGold;
			}
			m_Load.close();

			m_Load.open("SavePlayer" + to_string(select) + ".txt");
			m_Load >> m_ActorData[PLAYER].strName >> m_ActorData[PLAYER].iLv >> m_ActorData[PLAYER].iAtk >> m_ActorData[PLAYER].iHP >> m_ActorData[PLAYER].iHPMax
				>> m_ActorData[PLAYER].iExp >> m_ActorData[PLAYER].iExpMax >> m_ActorData[PLAYER].iLootExp >> m_ActorData[PLAYER].iGold;

			int tmpWeaponNumber = -1;
			m_Load >> tmpWeaponNumber;
			m_Player.SetWeaponNumber(tmpWeaponNumber);
			m_Player.SetWeapon(m_Weapon);

			MapDraw::DrawMidText("==�ε� �Ϸ�==", m_iGameWidth, 25);
			Sleep(500);
			return true;
		}
		
	}
	else
	{
		MapDraw::DrawMidText("==������ ����==", m_iGameWidth, 25);
		Sleep(500);
		return false;
	}
		
	m_Load.close();	
}

void GameManager::RenewalActorData()
{
	m_Player.RenewalStatManage(m_ActorData[PLAYER].strName, m_ActorData[PLAYER].iLv, m_ActorData[PLAYER].iAtk, m_ActorData[PLAYER].iHP, m_ActorData[PLAYER].iHPMax,
		m_ActorData[PLAYER].iExp, m_ActorData[PLAYER].iExpMax, m_ActorData[PLAYER].iLootExp, m_ActorData[PLAYER].iGold);

	for (int i = 0; i < m_iMonsterNumber; i++)
	{
		m_Monster[i].RenewalStatManage(m_ActorData[i].strName, m_ActorData[i].iLv, m_ActorData[i].iAtk, m_ActorData[i].iHP, m_ActorData[i].iHPMax,
			m_ActorData[i].iExp, m_ActorData[i].iExpMax, m_ActorData[i].iLootExp, m_ActorData[i].iGold);
	}
	
}

void GameManager::BattleScene(int select)
{
	MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
	
			
	MapDraw::DrawMidText("���� : 1  ���� : 2  �� : 3", m_iGameWidth, 9);
	MapDraw::DrawMidText("-------------------- VS --------------------", m_iGameWidth, m_iGameHeight / 2);
	while (m_Player.GetHP() > 0 && m_Monster[select - 1].GetHP() > 0)
	{
		MapDraw::DrawMidText("                                       ", m_iGameWidth, 4);
		MapDraw::DrawMidText("                                       ", m_iGameWidth, 24);
		m_Player.ShowStat(3);
		m_Monster[select - 1].ShowStat(23);
		Battle(select);
	}
	BattleResult(select);
	LevelUpCheck(select);
	
}

void GameManager::Battle(int select)
{
	int actResultPlayer = m_Player.Act();
	int actResultMonster = m_Monster[select - 1].Act();
	if (actResultPlayer == SCISSORS)
	{
		if (actResultMonster== PAPER)
		{
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" �� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Win ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Lose ", m_iGameWidth, m_iGameHeight / 2 + 2);
			m_Monster[select - 1].Damage(m_Player.GetAtk());
			m_Monster[select - 1].Damage(m_Player.WeaponDamage());
		}
		else if (actResultMonster == ROCK)
		{
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Lose ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Win ", m_iGameWidth, m_iGameHeight / 2 + 2);
			m_Player.Damage(m_Monster[select - 1].GetAtk());
		}
		else
		{
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Draw ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Draw ", m_iGameWidth, m_iGameHeight / 2 + 2);
		}
	}
	else if (actResultPlayer == ROCK)
	{
		if (actResultMonster == SCISSORS)
		{
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Win ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Lose ", m_iGameWidth, m_iGameHeight / 2 + 2);
			m_Monster[select - 1].Damage(m_Player.GetAtk());
			m_Monster[select - 1].Damage(m_Player.WeaponDamage());
		}
		else if (actResultMonster == PAPER)
		{
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" �� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Lose ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Win ", m_iGameWidth, m_iGameHeight / 2 + 2);
			m_Player.Damage(m_Monster[select - 1].GetAtk());
		}
		else
		{
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Draw ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Draw ", m_iGameWidth, m_iGameHeight / 2 + 2);
		}
	}
	else if (actResultPlayer == PAPER)
	{
		if (actResultMonster == ROCK)
		{
			MapDraw::DrawMidText(" �� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Win ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Lose ", m_iGameWidth, m_iGameHeight / 2 + 2);
			m_Monster[select - 1].Damage(m_Player.GetAtk());
			m_Monster[select - 1].Damage(m_Player.WeaponDamage());
		}
		else if (actResultMonster == SCISSORS)
		{
			MapDraw::DrawMidText(" �� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" ���� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Lose ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Win ", m_iGameWidth, m_iGameHeight / 2 + 2);
			m_Player.Damage(m_Monster[select - 1].GetAtk());
		}
		else
		{
			MapDraw::DrawMidText(" �� ", m_iGameWidth, m_iGameHeight / 2 - 3);
			MapDraw::DrawMidText(" �� ", m_iGameWidth, m_iGameHeight / 2 + 3);
			MapDraw::DrawMidText(" Draw ", m_iGameWidth, m_iGameHeight / 2 - 2);
			MapDraw::DrawMidText(" Draw ", m_iGameWidth, m_iGameHeight / 2 + 2);
		}
	}
}

void GameManager::SelectDungeon()
{
	int select = 0;	
	while (select != DUNGEON_BACK && m_bGameOver == false)
	{
		system("cls");
		MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
		MapDraw::DrawMidText("====== ���� �Ա� ======", m_iGameWidth, 6);
		for (int i = 0; i < m_iMonsterNumber; i++)
		{
			MapDraw::DrawMidText(to_string(i + 1) + "������ : [" + m_Monster[i].GetName() + "]", m_iGameWidth, 11 + i * 2);
			if (i == m_iMonsterNumber - 1)
				MapDraw::DrawMidText("���ư���", m_iGameWidth, 13 + i * 2);
		}
		select = MapDraw::MenuSelectCursor(m_iMonsterNumber + 1, 2, m_iGameWidth / 4, 11);
		if (select <= DUNGEON_6 && select >= DUNGEON_1)
			BattleScene(select);
		else if (select == DUNGEON_BACK)
			break;
		else
			continue;

	}	

}

void GameManager::BattleResult(int select)
{
	system("cls");
	MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
	if (m_Player.GetHP() > 0)
	{
		m_Player.ResultExp(m_Monster[select - 1].GetLootExp());
		m_Player.ResultGold(m_Monster[select - 1].GetGold());
		MapDraw::DrawMidText(m_Player.GetName() + "�¸�!", m_iGameWidth, m_iGameWidth / 3);
		MapDraw::DrawMidText(m_Player.GetName() + "��(��) " + to_string(m_Monster[select - 1].GetLootExp()) + "�� ����ġ�� ȹ���ߴ�.", m_iGameWidth, m_iGameWidth / 3 + 2);
		m_Monster[select - 1].resetHp();
	}
	else if(m_Monster[select -1].GetHP() > 0)
	{
		m_Monster[select - 1].ResultExp(m_Player.GetLootExp());
		m_Monster[select - 1].ResultGold(m_Player.GetGold());
		MapDraw::DrawMidText(m_Monster[select - 1].GetName() + "�¸�!", m_iGameWidth, m_iGameWidth / 3);
		MapDraw::DrawMidText(m_Monster[select - 1].GetName() + "��(��) " + to_string(m_Player.GetLootExp()) + "�� ����ġ�� ȹ���ߴ�.", m_iGameWidth, m_iGameWidth / 3 + 2);
		MapDraw::DrawMidText("Game Over", m_iGameWidth, m_iGameWidth / 3 + 4);
		m_bGameOver = true;
	}
	getch();
}

void GameManager::LevelUpCheck(int select)
{
	
	if (m_Player.GetHP() > 0 && m_Player.ExpOverCheck())
	{
		system("cls");
		MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
		m_Player.LevelUp();
		MapDraw::DrawMidText(m_Player.GetName() + " ������!", m_iGameWidth, m_iGameHeight / 2);
		getch();
	}
	else if (m_Monster[select - 1].GetHP() > 0 && m_Monster[select - 1].ExpOverCheck())
	{
		system("cls");
		MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
		m_Monster[select - 1].LevelUp();
		MapDraw::DrawMidText(m_Monster[select -1].GetName() + " ������!", m_iGameWidth, m_iGameHeight / 2);
		getch();
	}
	
}

void GameManager::WeaponList()
{
	m_Save.open("WeaponList.txt");
	if (m_Save.is_open())
	{
		m_Save <<
			"30" << endl <<
			"5"<< endl <<
			"6" << endl <<
			"4" << endl <<
			"5" << endl <<
			"5" << endl <<
			"5" << endl <<

			"Bow ����Ʈ���� 10 20" << endl <<
			"Bow ũ�ν����� 15 30" << endl <<
			"Bow ��ź�Ƶ�Ʈ 30 60" << endl <<
			"Bow ��ǳ�ǿ��� 50 100" << endl <<
			"Bow �������巹�� 150 300" << endl <<
			
			"Dagger �������� 5 10" << endl <<
			"Dagger �ǹ�����Ʈ 10 40" << endl <<
			"Dagger �𿣵� 30 120" << endl <<
			"Dagger ��ְ̽� 50 200" << endl <<
			"Dagger â���Ǳ����� 80 320" << endl <<
			"Dagger ���� 150 350" << endl <<
			
			"Gun ������ 15 30" << endl <<
			"Gun ������ 25 50" << endl <<
			"Gun ������ 40 80" << endl <<
			"Gun ���¶��̴� 120 240" << endl <<
			
			"Sword �ǹ��ҵ� 13 30" << endl <<
			"Sword ��������� 33 70" << endl <<
			"Sword �ֵ��ν� 45 100" << endl <<
			"Sword ����� 80 180" << endl <<
			"Sword �����ҵ� 150 350" << endl <<
			
			"Wand ���������� 12 20" << endl <<
			"Wand ��������� 25 40" << endl <<
			"Wand ���丣�ǹ�� 40 70" << endl <<
			"Wand ��ȣũ��Ʈ 85 150" << endl <<
			"Wand ������������ 180 320" << endl <<
			
			"Hammer ��ö��ġ 30 70" << endl <<
			"Hammer �丣�Ǹ�ġ 50 110" << endl <<
			"Hammer �̽������� 75 170" << endl <<
			"Hammer ���Ŭ���� 150 320" << endl <<
			"Hammer �������� 210 450";
	} 
	m_Save.close();
}

void GameManager::WeaponSetting() //load
{
	m_Load.open("WeaponList.txt");
	
	m_Load >> m_iWeaponNumber; //30

	for (int i = 0; i < WEAPONTYPE_NUMBER; i++)
	{
		m_Load >> m_iWeaponCount[i];
	}

	string tmpType;
	string tmpName;
	int tmpDamage;
	int tmpCost;

	m_Weapon = new Weapon[m_iWeaponNumber];

	for (int i = 0; i < m_iWeaponNumber; i++)
	{
		m_Load >> tmpType >> tmpName >> tmpDamage >> tmpCost;
		m_Weapon[i].SetData(tmpType, tmpName, tmpDamage, tmpCost);
	}
	m_Load.close();

}

void GameManager::WeaponShopMenu() //���⼥ ��ü�޴�
{
	int select = 0;
	system("cls");
	BLUE
	MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);
	MapDraw::DrawMidText("�� �� S H O P �� ��", m_iGameWidth, m_iGameHeight / 4);
	MapDraw::DrawMidText("Bow", m_iGameWidth, m_iGameHeight / 4 + 2);
	MapDraw::DrawMidText("Dagger", m_iGameWidth, m_iGameHeight / 4 + 4);
	MapDraw::DrawMidText("Gun", m_iGameWidth, m_iGameHeight / 4 + 6);
	MapDraw::DrawMidText("Sword", m_iGameWidth, m_iGameHeight / 4 + 8);
	MapDraw::DrawMidText("Wand", m_iGameWidth, m_iGameHeight / 4 + 10);	
	MapDraw::DrawMidText("Hammer", m_iGameWidth, m_iGameHeight / 4 + 12);
	MapDraw::DrawMidText("���ư���", m_iGameWidth, m_iGameHeight / 4 + 14);
	ORIGINAL

	select = MapDraw::MenuSelectCursor(7, 2, m_iGameWidth / 2 - 4, m_iGameHeight / 4 + 2); //����ȭ��ǥ ��������
	if (select >= SHOP_BOW && select <= SHOP_HAMMER)
		WeaponPurchaseMenu(select);
	else
		return;

}

void GameManager::WeaponPurchaseMenu(int select)//�� ���� Ÿ�Ժ��� ���Ű����ϰ� �����ϴ� �޴� //�����ϴ� ������ ������ �κ��� �÷��̾� �Լ��� �ֱ�
{
	
	switch ((SHOP)select)
	{
	case SHOP_BOW:
		WeaponPurchaseSelect(select, "Bow");
		break;
	case SHOP_DAGGER:
		WeaponPurchaseSelect(select, "Dagger");
		break;
	case SHOP_GUN:
		WeaponPurchaseSelect(select, "Gun");
		break;
	case SHOP_SWORD:
		WeaponPurchaseSelect(select, "Sword");
		break;
	case SHOP_WAND:
		WeaponPurchaseSelect(select, "Wand");
		break;
	case SHOP_HAMMER:
		WeaponPurchaseSelect(select, "Hammer");
		break;
	default:
		break;
	}
	
}

void GameManager::WeaponTypeShopText(int select)
{
	switch (select)
	{
	case SHOP_BOW:
		MapDraw::DrawMidText("Bow Shop",m_iGameWidth, 2);
		break;
	case SHOP_DAGGER:
		MapDraw::DrawMidText("Dagger Shop", m_iGameWidth, 2);
		break;
	case SHOP_GUN:
		MapDraw::DrawMidText("Gun Shop", m_iGameWidth, 2);
		break;
	case SHOP_SWORD:
		MapDraw::DrawMidText("Sword Shop", m_iGameWidth, 2);
		break;
	case SHOP_WAND:
		MapDraw::DrawMidText("Wand Shop", m_iGameWidth, 2);
		break;
	case SHOP_HAMMER:
		MapDraw::DrawMidText("Hammer Shop", m_iGameWidth, 2);
		break;
	default:
		break;
	}
}

void GameManager::WeaponPurchaseSelect(int select, string weaponType) //Ŭ���� ���� string ���� Ÿ���� ��ġ�ϰ� �����
{
	int weaponBeginIdxSum[WEAPONTYPE_NUMBER]; //0~5
	int sum = 0;
	int purchase = 0;
	int idx = 0;
	int listNum = 0;
	bool nextPage = false;
	int leftList = 0;
	bool underFive = false;

	for (int i = 0; i < WEAPONTYPE_NUMBER; i++)
	{
		weaponBeginIdxSum[i] = sum; //5,6,4,5,5,5
		sum += m_iWeaponCount[i];
	}

	idx = weaponBeginIdxSum[select - 1];

	if (m_iWeaponCount[select - 1] < 5) //������� 5�� �̸��ϰ��
	{
		listNum = m_iWeaponCount[select - 1];
		underFive = true;
	}
	else
	{
		listNum = 5;
		leftList = m_iWeaponCount[select - 1] % 5;
	}

	while (1)
	{
		if (nextPage == true)
		{
			listNum = leftList;
		}
		else if (nextPage == false)
		{
			if (underFive == false)
				listNum = 5;
			else
				listNum = m_iWeaponCount[select - 1];
		}

		system("cls");
		MapDraw::BoxDraw(0, 0, m_iGameWidth, m_iGameHeight);

		MapDraw::DrawMidText("���� �ݾ� : ", m_iGameWidth, 3);
		cout << m_Player.GetGold();
		WeaponTypeShopText(select); //1�̸� ����

		MapDraw::DrawMidText("����������", m_iGameWidth, 6 + 3 * listNum);
		MapDraw::DrawMidText("����������", m_iGameWidth, 9 + 3 * listNum);
		MapDraw::DrawMidText("������", m_iGameWidth, 12 + 3 * listNum);
				

		for (int i = 0; i < listNum; i++)
		{
			m_Weapon[idx + i].ShowCost(4, 6 + 3 * i);
			m_Weapon[idx + i].ShowInformation(4, 7 + 3 * i);
		}

		purchase = MapDraw::MenuSelectCursor(listNum + 3, 3, 2, 6);

		if (purchase <= listNum)
		{
			Weapon tmpWeapon = m_Weapon[idx - 1 + purchase];
			if (m_Player.GetGold() >= tmpWeapon.GetCost())
			{
				if (m_Player.pGetWeaponStorage() == nullptr)
					m_Player.WeaponStorage();
				m_Player.SetWeaponNumber(idx - 1 + purchase);
				m_Player.Purchase(tmpWeapon, tmpWeapon.GetCost());
			}			
		}
		else
		{
			if (purchase == listNum + 1)
			{
				if (nextPage == true) //2�������϶�
				{
					idx -= 5;					
					nextPage = false;
					continue;
				}				
			}
			else if(purchase == listNum + 2)
			{
				if (nextPage == false)//1�������϶�
				{
					idx += 5;					
					nextPage = true;
					continue;
				}

			}
			else if(purchase == listNum + 3)
			{
				return;
			}

		}
	}	
}
