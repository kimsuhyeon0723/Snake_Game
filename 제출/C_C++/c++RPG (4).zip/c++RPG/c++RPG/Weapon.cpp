#include "Weapon.h"

void Weapon::ShowInformation(int x, int y)
{
	MapDraw::TextDraw("����Ÿ��: " + m_strWeaponType + " �����̸�: " + m_strWeaponName + " ���ݷ�: " + to_string(m_iDamage), 2*x, y);
}

void Weapon::ShowCost(int x, int y)
{
	MapDraw::TextDraw("���� : " + to_string(m_iCost), 2*x, y);
}

int Weapon::GetDamage()
{
	return m_iDamage;
}

int Weapon::GetCost()
{
	return m_iCost;
}

void Weapon::SetData(string strWeaponType, string strWeaponName, int iDamage, int iCost)
{
	m_strWeaponType = strWeaponType;
	m_strWeaponName = strWeaponName;
	m_iDamage = iDamage;
	m_iCost = iCost;
}

string Weapon::GetWeaponType()
{
	return m_strWeaponType;
}

Weapon::Weapon()
{
	m_strWeaponType = "null";
	m_strWeaponName = "null";
	m_iDamage = 0;
	m_iCost = 0;
}