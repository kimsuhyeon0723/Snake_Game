﻿#include <iostream>
using namespace std;

template <typename T>
void PlusOne(T& num)
{
	num++;
}

template <typename T>
T FindMin(T num1, T num2)
{
	if (num1 <= num2)
	{
		return num1;
	}
	else
	{
		return num2;
	}
}

template<typename T1, typename T2, typename T3, typename T4>
T1 FindMax(T2 num1, T3 num2, T4 num3)
{
	if (num1 >= num2)
	{
		if (num1 >= num3)
			return num1;
		else
			return num3;
	}
	else
	{
		if (num2 >= num3)
			return num2;
		else
			return num3;
	}
}

int main()
{
	float a=0, b=0, c=0;
	cout << "1. 하나의 실수 입력후 1 더한 값 출력 : ";
	cin >> a;
	PlusOne(a);
	cout << "결과 : " << a << endl << endl;
	cout << "2. 두개의 실수 입력후 작은값 출력" << endl;
	cout << "값1 입력 : ";
	cin >> a;
	cout << "값2 입력 : ";
	cin >> b;
	cout << "작은값 : " << FindMin<float>(a, b) << endl << endl;
	cout << "3.  세 개의 실수 입력후 큰값 출력" << endl;
	cout << "값1 입력 : ";
	cin >> a;
	cout << "값2 입력 : ";
	cin >> b;
	cout << "값3 입력 : ";
	cin >> c;
	cout << "큰 값: " << FindMax<float>(a, b, c) << endl;
}

