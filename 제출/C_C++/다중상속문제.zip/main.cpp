﻿#include "Student.h"

void main()
{
	Student student;
	student.InputInfo();
	student.Info();
	system("pause");
}

