#pragma once
#include "head.h"

class Person
{	
protected:
	int m_iAge;
	string m_strGender;
	string m_strName;
public:
	Person();
	void Input();
};

