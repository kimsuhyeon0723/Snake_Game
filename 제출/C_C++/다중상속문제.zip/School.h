#pragma once
#include "head.h"

class School
{
protected:
	int m_iGrade;
	string m_strClass;
	int m_iNum;

public:
	School();
	void Input();
};

