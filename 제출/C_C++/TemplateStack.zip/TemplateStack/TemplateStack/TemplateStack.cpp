﻿#include <iostream>
using namespace std;

template <typename T>
class Stack 
{
private:
	int top, Length;
	T* stack;
public:
	Stack(int size);
	bool isFull(), isEmpty();
	T pop();
	void push(T data);
	void print();
	~Stack();
};

template <typename T>
Stack<T>::Stack(int size)
{
	Length = size;
	stack = new T[Length];
	top = -1;
}

template <typename T>
Stack<T>::~Stack()
{
	delete[] stack;
}

template <typename T>
bool Stack<T>::isFull() 
{
	if (top == Length - 1) 
		return 1;
	else 
		return 0;
}

template <typename T>
bool Stack<T>::isEmpty() 
{
	if (top == -1)
		return 1;
	else 
		return 0;
}

template <typename T>
T Stack<T>::pop() 
{
	if (isEmpty() == 1) 
		cout << "Empty!\n";
	else
	{
		cout << "pop top" << endl;
		return stack[top--];
	}
		
}

template <typename T>
void Stack<T>::push(T data) {
	if (isFull() == 1) 
		cout << "Full!\n";
	else
	{
		stack[++top] = data;
		cout << "push : " << data << endl;
	}
		
}

template <typename T>
void Stack<T>::print() {
	for (int i = 0; i < top + 1; ++i)
		cout <<""<<stack[i] << endl;
}

int main()
{
	Stack<char> chStack(3);
	chStack.push('a');
	chStack.push('b');
	chStack.pop();
	chStack.push('c');
	chStack.push('z');
	chStack.print();

	Stack<int> iStack(5);
	for (int i = 0; i <= 5; i++)
	{
		iStack.push(i);
	}
	iStack.print();
}