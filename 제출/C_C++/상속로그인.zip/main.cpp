﻿#include "Login.h"

void main()
{	
	Login lg;
	lg.Init();
}

