#pragma once
#include <iostream>
#include <string>
#include<Windows.h>
using namespace std;

#define IDLEN 3
#define PASSWORDLEN 8
#define IDMAX 10
