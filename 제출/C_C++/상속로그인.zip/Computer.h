#pragma once
#include "head.h"

struct ID
{
	string Id;
	string Password;
	string Name;
	int Age;
	string PhonNumber;
	int Mileage;
	
};

class Computer//�޸���, �׸���, ���� ����� �ڽ��� ����ϵ���
{
protected:
	int Id_Count = 0;
	ID Id_List[IDMAX];
	string TmpId, TmpPassword;
	int Select;
	bool Id_Flag, PasswordFlag, LoginFlag;
	
public:
	void Menu(int Num);
	void PCFunction();
	void Init();
	bool StringCheck(char Start, char End, char Check);
	void Join(ID* P1, int Id_Count, ID Id_List[]);
	void SimpleShowID(ID id);
	void ShowID(ID id);
	void Setstring(string* str, string tmp);
	void Setint(int* num, string tmp);
	void SetID(ID* id);
	void Display(ID* id);
	void PCInfo();
	Computer();
};

